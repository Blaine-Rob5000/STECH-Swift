//
//  ViewController.swift
//  RyteByteApp
//
//  Created by Student on 2/14/18.
//  Copyright © 2018 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var logoR: UIImageView!
    @IBOutlet weak var logoYte1: UIImageView!
    @IBOutlet weak var logoB: UIImageView!
    @IBOutlet weak var logoYte2: UIImageView!
    @IBOutlet weak var logoTM: UIImageView!
    @IBOutlet weak var companyName: UIImageView!
    @IBOutlet weak var logoChomp: UIImageView!
    @IBOutlet weak var messageBackdrop: UIImageView!
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var aboutButtonImage: UIImageView!
    @IBOutlet weak var aboutButton: UIButton!
    @IBOutlet weak var storeButtonImage: UIImageView!
    @IBOutlet weak var storeButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        assembleLogo()
    }
    

    @IBAction func assembleLogo() {

        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0.8, options: .curveEaseInOut, animations: {
            self.companyName.transform = CGAffineTransform(translationX: 0, y: 364)
        }, completion: nil)
        
        UIView.animate(withDuration: 1, delay: 0.1, usingSpringWithDamping: 0.7, initialSpringVelocity: 0.8, options: .curveEaseInOut, animations: {
            self.logoB.transform = CGAffineTransform(translationX: 0, y: 267)
        }, completion: nil)
        
        UIView.animate(withDuration: 1, delay: 0.2, usingSpringWithDamping: 0.7, initialSpringVelocity: 0.8, options: .curveEaseInOut, animations: {
            self.logoYte2.transform = CGAffineTransform(translationX: 0, y: 312)
        }, completion: nil)
        
        UIView.animate(withDuration: 1, delay: 0.3, usingSpringWithDamping: 0.7, initialSpringVelocity: 0.8, options: .curveEaseInOut, animations: {
            self.logoTM.transform = CGAffineTransform(translationX: 0, y: 312)
        }, completion: nil)
        
        UIView.animate(withDuration: 1, delay: 0.4, usingSpringWithDamping: 0.7, initialSpringVelocity: 0.8, options: .curveEaseInOut, animations: {
            self.logoR.transform = CGAffineTransform(translationX: 0, y: 228)
        }, completion: nil)
        
        UIView.animate(withDuration: 1, delay: 0.5, usingSpringWithDamping: 0.7, initialSpringVelocity: 0.8, options: .curveEaseInOut, animations: {
            self.logoYte1.transform = CGAffineTransform(translationX: 0, y: 223)
        }, completion: nil)
        
        UIView.animate(withDuration: 1, delay: 0.6, usingSpringWithDamping: 0.7, initialSpringVelocity: 0.8, options: .curveEaseInOut, animations: {
            self.logoChomp.transform = CGAffineTransform(translationX: 0, y: 210)
        }, completion: nil)
 

    
    

    

    


    }
}

