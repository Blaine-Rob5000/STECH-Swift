//
//  ViewController.swift
//  RyteByteApp
//
//  Created by Student on 2/14/18.
//  Copyright © 2018 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        assembleLogo()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBOutlet weak var logoR: UIImageView!          // final pos: 95,  72
    @IBOutlet weak var logoYte1: UIImageView!       // final pos: 166, 66
    @IBOutlet weak var logoB: UIImageView!          // final pos: 146, 109
    @IBOutlet weak var logoYte2: UIImageView!       // final pos: 214, 154
    @IBOutlet weak var logoTM: UIImageView!         // final pos: 284, 160
    @IBOutlet weak var logoChomp: UIImageView!      // final pos: 240, 51
    @IBOutlet weak var companyName: UIImageView!    // final pos: 58,  206

    @IBAction func assembleLogo() {
        
        UIView.animate(withDuration: 0.5, delay: 0.30, usingSpringWithDamping: 0.7, initialSpringVelocity: 0.8, options: .curveEaseInOut, animations: {
            self.logoChomp.transform = CGAffineTransform(translationX: 244, y: 110)
        }, completion: nil)
 
        UIView.animate(withDuration: 0.5, delay: 0.25, usingSpringWithDamping: 0.7, initialSpringVelocity: 0.8, options: .curveEaseInOut, animations: {
            self.logoR.transform = CGAffineTransform(translationX: 98, y: 128)
        }, completion: nil)
    
        UIView.animate(withDuration: 0.5, delay: 0.20, usingSpringWithDamping: 0.7, initialSpringVelocity: 0.8, options: .curveEaseInOut, animations: {
            self.logoYte1.transform = CGAffineTransform(translationX: 170, y: 123)
        }, completion: nil)
    
        UIView.animate(withDuration: 0.5, delay: 0.15, usingSpringWithDamping: 0.7, initialSpringVelocity: 0.8, options: .curveEaseInOut, animations: {
            self.logoB.transform = CGAffineTransform(translationX: 146, y: 167)
        }, completion: nil)
    
        UIView.animate(withDuration: 0.5, delay: 0.10, usingSpringWithDamping: 0.7, initialSpringVelocity: 0.8, options: .curveEaseInOut, animations: {
            self.logoYte2.transform = CGAffineTransform(translationX: 214, y: 212)
        }, completion: nil)
    
        UIView.animate(withDuration: 0.5, delay: 0.05, usingSpringWithDamping: 0.7, initialSpringVelocity: 0.8, options: .curveEaseInOut, animations: {
            self.logoTM.transform = CGAffineTransform(translationX: 287, y: 212)
        }, completion: nil)
    
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0.8, options: .curveEaseInOut, animations: {
            self.companyName.transform = CGAffineTransform(translationX: 64, y: 264)
        }, completion: nil)

    }
}

